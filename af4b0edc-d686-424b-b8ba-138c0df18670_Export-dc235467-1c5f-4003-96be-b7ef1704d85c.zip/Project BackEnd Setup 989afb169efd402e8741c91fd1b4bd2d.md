# Project BackEnd Setup

1. follow this 
    
    [Deploy to Cloudflare Workers](https://www.prisma.io/docs/orm/prisma-client/deployment/edge/deploy-to-cloudflare-workers)
    
2. install postgress 
3. create Postgress DB using Neon 
4. install prisma 
    
    ```jsx
    npm init -y
    npm install typescript ts-node @types/node --save-dev
    
    //Now, initialize TypeScript:
    npx tsc --init 
    
    //Then, install the Prisma CLI as a development dependency in the project
    npm install prisma --save-dev
    
    ```
    
5. Run a migration to create your database tables with Prisma Migrate
    
    ```jsx
    npx prisma migrate dev --name init
    ```
    
6. generate 
    
    ```jsx
    npx prisma generate --no-engine
    ```
    
7. npm run dev 
8. npm run deploy
9. Prisma accelerate
    
    [](https://console.prisma.io/clsygcjma0iibzw0t23u7fwg8/overview)
    

###