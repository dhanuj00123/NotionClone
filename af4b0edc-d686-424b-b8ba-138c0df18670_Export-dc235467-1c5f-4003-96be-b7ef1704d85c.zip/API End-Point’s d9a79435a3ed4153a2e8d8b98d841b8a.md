# API End-Point’s

### Notes Endpoints:

1. **Create Note**: `POST /api/notes`
    - Request Body:
        
        ```json
        {
          "title": "Note Title",
          "content": "Note Content"
        }
        
        ```
        
    - Response Body (Example):
        
        ```json
        {
          "id": 1,
          "title": "Note Title",
          "content": "Note Content",
          "createdAt": "2024-02-23T12:00:00Z",
          "updatedAt": "2024-02-23T12:00:00Z",
          "userId": 1
        }
        
        ```
        
2. **Get All Notes**: `GET /api/notes`
    - Response Body (Example):
        
        ```json
        [
          {
            "id": 1,
            "title": "Note Title 1",
            "content": "Note Content 1",
            "createdAt": "2024-02-23T12:00:00Z",
            "updatedAt": "2024-02-23T12:00:00Z",
            "userId": 1
          },
          {
            "id": 2,
            "title": "Note Title 2",
            "content": "Note Content 2",
            "createdAt": "2024-02-23T12:05:00Z",
            "updatedAt": "2024-02-23T12:05:00Z",
            "userId": 1
          }
        ]
        
        ```
        
3. **Get Note by ID**: `GET /api/notes/:id`
    - Response Body (Example):
        
        ```json
        {
          "id": 1,
          "title": "Note Title",
          "content": "Note Content",
          "createdAt": "2024-02-23T12:00:00Z",
          "updatedAt": "2024-02-23T12:00:00Z",
          "userId": 1
        }
        
        ```
        
4. **Update Note**: `PUT /api/notes/:id`
    - Request Body:
        
        ```json
        {
          "title": "Updated Note Title",
          "content": "Updated Note Content"
        }
        
        ```
        
    - Response Body (Example):
        
        ```json
        {
          "id": 1,
          "title": "Updated Note Title",
          "content": "Updated Note Content",
          "createdAt": "2024-02-23T12:00:00Z",
          "updatedAt": "2024-02-23T12:10:00Z",
          "userId": 1
        }
        
        ```
        
5. **Delete Note**: `DELETE /api/notes/:id`
    - Response Body (Example):
        
        ```json
        {
          "message": "Note with ID 1 deleted successfully"
        }
        
        ```
        

### Mind Maps Endpoints:

1. **Create Mind Map**: `POST /api/mindmaps`
    - Request Body:
        
        ```json
        {
          "title": "Mind Map Title"
        }
        
        ```
        
    - Response Body (Example):
        
        ```json
        {
          "id": 1,
          "title": "Mind Map Title",
          "createdAt": "2024-02-23T12:00:00Z",
          "updatedAt": "2024-02-23T12:00:00Z",
          "userId": 1
        }
        
        ```
        
2. **Get All Mind Maps**: `GET /api/mindmaps`
    - Response Body (Example):
        
        ```json
        [
          {
            "id": 1,
            "title": "Mind Map Title 1",
            "createdAt": "2024-02-23T12:00:00Z",
            "updatedAt": "2024-02-23T12:00:00Z",
            "userId": 1
          },
          {
            "id": 2,
            "title": "Mind Map Title 2",
            "createdAt": "2024-02-23T12:05:00Z",
            "updatedAt": "2024-02-23T12:05:00Z",
            "userId": 1
          }
        ]
        
        ```
        
3. **Get Mind Map by ID**: `GET /api/mindmaps/:id`
    - Response Body (Example):
        
        ```json
        {
          "id": 1,
          "title": "Mind Map Title",
          "createdAt": "2024-02-23T12:00:00Z",
          "updatedAt": "2024-02-23T12:00:00Z",
          "userId": 1
        }
        
        ```
        
4. **Update Mind Map**: `PUT /api/mindmaps/:id`
    - Request Body:
        
        ```json
        {
          "title": "Updated Mind Map Title"
        }
        
        ```
        
    - Response Body (Example):
        
        ```json
        {
          "id": 1,
          "title": "Updated Mind Map Title",
          "createdAt": "2024-02-23T12:00:00Z",
          "updatedAt": "2024-02-23T12:10:00Z",
          "userId": 1
        }
        
        ```
        
5. **Delete Mind Map**: `DELETE /api/mindmaps/:id`
- Response Body (Example):
    
    ```json
    {
      "message": "Mind Map with ID 1 deleted successfully"
    }
    
    ```
    

### Calendar Events Endpoints:

1. **Create Calendar Event**: `POST /api/calendarevents`
    - Request Body:
        
        ```json
        {
          "title": "Event Title",
          "startDate": "2024-02-23T08:00:00Z",
          "endDate": "2024-02-23T10:00:00Z",
          "location": "Event Location"
        }
        
        ```
        
    - Response Body (Example):
        
        ```json
        {
          "id": 1,
          "title": "Event Title",
          "startDate": "2024-02-23T08:00:00Z",
          "endDate": "2024-02-23T10:00:00Z",
          "location": "Event Location",
          "createdAt": "2024-02-23T12:00:00Z",
          "updatedAt": "2024-02-23T12:00:00Z",
          "userId": 1
        }
        
        ```
        
2. **Get All Calendar Events**: `GET /api/calendarevents`
    - Response Body (Example):
        
        ```json
        [
          {
            "id": 1,
            "title": "Event Title 1",
            "startDate": "2024-02-23T08:00:00Z",
            "endDate": "2024-02-23T10:00:00Z",
            "location": "Event Location 1",
            "createdAt": "2024-02-23T12:00:00Z",
            "updatedAt": "2024-02-23T12:00:00Z",
            "userId": 1
          },
          {
            "id": 2,
            "title": "Event Title 2",
            "startDate": "2024-02-24T08:00:00Z",
            "endDate": "2024-02-24T10:00:00Z",
            "location": "Event Location 2",
            "createdAt": "2024-02-23T12:05:00Z",
            "updatedAt": "2024-02-23T12:05:00Z",
            "userId": 1
          }
        ]
        
        ```
        
3. **Get Calendar Event by ID**: `GET /api/calendarevents/:id`
    - Response Body (Example):
        
        ```json
        {
          "id": 1,
          "title": "Event Title",
          "startDate": "2024-02-23T08:00:00Z",
          "endDate": "2024-02-23T10:00:00Z",
          "location": "Event Location",
          "createdAt": "2024-02-23T12:00:00Z",
          "updatedAt": "2024-02-23T12:00:00Z",
          "userId": 1
        }
        
        ```
        
4. **Update Calendar Event**: `PUT /api/calendarevents/:id`
    - Request Body:
        
        ```json
        {
          "title": "Updated Event Title",
          "location": "Updated Event Location"
        }
        
        ```
        
    - Response Body (Example):
        
        ```json
        {
          "id": 1,
          "title": "Updated Event Title",
          "startDate": "2024-02-23T08:00:00Z",
          "endDate": "2024-02-23T10:00:00Z",
          "location": "Updated Event Location",
          "createdAt": "2024-02-23T12:00:00Z",
          "updatedAt": "2024-02-23T12:10:00Z",
          "userId": 1
        }
        
        ```
        
5. **Delete Calendar Event**: `DELETE /api/calendarevents/:id`
    - Response Body (Example):
        
        ```json
        {
          "message": "Calendar Event with ID 1 deleted successfully"
        }
        
        ```
        

### User Profile Endpoints:

1. **Get User Profile**: `GET /api/profile`
    - Response Body (Example):
        
        ```json
        {
          "id": 1,
          "username": "user1",
          "email": "user1@example.com",
          "createdAt": "2024-02-23T12:00:00Z",
          "updatedAt": "2024-02-23T12:00:00Z"
        }
        
        ```
        
2. **Update User Profile**: `PUT /api/profile`
    - Request Body:
        
        ```json
        {
          "username": "updated_user1",
          "email": "updated_user1@example.com"
        }
        
        ```
        
    - Response Body (Example):
        
        ```json
        {
          "id": 1,
          "username": "updated_user1",
          "email": "updated_user1@example.com",
          "createdAt": "2024-02-23T12:00:00Z",
          "updatedAt": "2024-02-23T12:10:00Z"
        }
        
        ```
        

### Utility Endpoints:

1. **Get Server Time**: `GET /api/utilities/time`
    - Response Body (Example):
        
        ```json
        {
          "serverTime": "2024-02-23T12:30:00Z"
        }
        
        ```
        
2. **Get Weather Information**: `GET /api/utilities/weather`
    - Response Body (Example):
        
        ```json
        {
          "temperature": 22,
          "condition": "Sunny"
        }
        
        ```